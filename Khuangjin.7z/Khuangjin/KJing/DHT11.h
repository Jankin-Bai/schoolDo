#ifndef __DHT11_H__
#define __DHT11_H__
 
#include <Arduino.h>
 
//DHT11 IO设置
#define DHT11_DQ PB0
 
#define DHT11_DQ_0 digitalWrite(DHT11_DQ,LOW)
#define DHT11_DQ_1 digitalWrite(DHT11_DQ,HIGH)
 
//函数或者变量声明
extern void DHT11_Init();
extern unsigned char DHT11_Read_Byte();
extern void DHT11_Read();
 
extern unsigned char HUMI_Buffer_Int;
extern unsigned char TEM_Buffer_Int;
 
#endif
